const button = document.getElementById('surpriseBtn');
const letterOverlay = document.getElementById('letterOverlay');
const bgMusic = document.getElementById('bgMusic');
const heartRain = document.getElementById('heartRain');

if (bgMusic) {
  bgMusic.volume = 0.35;

  const startMusic = () => {
    bgMusic.play().then(() => {
      document.removeEventListener('pointerdown', startMusic);
      document.removeEventListener('keydown', startMusic);
      document.removeEventListener('touchstart', startMusic);
    }).catch(() => {});
  };

  startMusic();
  document.addEventListener('pointerdown', startMusic, { once: true });
  document.addEventListener('keydown', startMusic, { once: true });
  document.addEventListener('touchstart', startMusic, { once: true });
}

if (button && letterOverlay) {
  button.addEventListener('click', () => {
    const isHidden = letterOverlay.classList.contains('hidden');
    letterOverlay.classList.toggle('hidden');
    button.textContent = isHidden ? 'Fechar carta' : 'Abrir carta final';

    if (isHidden) {
      window.scrollTo({
        top: document.body.scrollHeight,
        behavior: 'smooth'
      });
    }
  });

  letterOverlay.addEventListener('click', (event) => {
    if (event.target === letterOverlay) {
      letterOverlay.classList.add('hidden');
      button.textContent = 'Abrir carta final';
    }
  });
}

if (heartRain) {
  setInterval(() => {
    const heart = document.createElement('span');
    heart.textContent = '❤';
    heart.style.left = `${Math.random() * 100}%`;
    heart.style.animationDuration = `${Math.random() * 4 + 5}s`;
    heart.style.setProperty('--drift', `${(Math.random() - 0.5) * 200}px`);
    heart.style.fontSize = `${Math.random() * 1.2 + 1.1}rem`;
    heartRain.appendChild(heart);

    setTimeout(() => heart.remove(), 9000);
  }, 500);
}
